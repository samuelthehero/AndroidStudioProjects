package com.emhp.pokedex;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.UiModeManager;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;

import com.emhp.pokedex.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    boolean cargarImagen = true;

    private ListView listView;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        listView = (ListView) findViewById(R.id.listView);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Fragment  fragment_imagen = null;

                if (cargarImagen){
                    fragment_imagen = new fragment_imagen();
                }

                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, fragment_imagen)
                        .commit();
                cargarImagen = !cargarImagen;
            }
        });

    }
}