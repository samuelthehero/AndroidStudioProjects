package com.emhp.pokedex;

import android.os.Bundle;

import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;


public class fragment_imagen extends Fragment {

    ImageView imageView;
    SearchView searchView;
    ArrayAdapter<ImageView> adapter;
    int[] data = {
            R.drawable.bulbasaur,
            R.drawable.charizard,
            R.drawable.charmander,
            R.drawable.charmeleon,
            R.drawable.pansage,
            R.drawable.pikachu,
            R.drawable.jigglypuff,
            R.drawable.squirtle,
            R.drawable.tipo_fuego,
            R.drawable.agua,
            R.drawable.electro,
            R.drawable.normal
    };

    public fragment_imagen(){

    }

    public fragment_imagen(int imageView) {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Create new fragment and transaction
        return inflater.inflate(R.layout.fragment_imagen, container, false);
    }
}