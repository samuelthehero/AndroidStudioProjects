package com.emhp.pokedex;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;

public class fragment_list extends Fragment {

    ListView lv;

    SearchView searchView;
    ArrayAdapter<String> adapter;
    String[] datos = {
            "Charizard",
            "Charmander",
            "Bulbasaur",
            "Pikachu",
            "Charmeleon",
            "Jigglypuff",
            "Pansage",
            "Squirtle"
    };

    public fragment_list() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_list, container, false);
        lv = (ListView) view.findViewById(R.id.listView);
        adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, datos);
        lv.setAdapter(adapter);
        // Inflate the layout for this fragment
        return view;
    }
}